const { Client } = require('pg');
const { Pool } = require('pg');
const client = new Client({
    host: 'postgre01python.postgres.database.azure.com',
    user: 'pedro',
    database: 'postgres',
    password: 'senhatirada123',
    port: 5432,
    ssl: true
});

const showProduct = async(produto) => {
    const query = `SELECT * 
                   FROM "vendas"
                   WHERE "nome_produto" = $1`;
    try {
        await client.connect();           
        var rows = await client.query(query, [produto]);
        return rows.rows[0]
    } catch (error) {
        console.error(error.stack);
        return false;
    } finally {
        await client.end();               
    }
};
module.exports = async function (context, req) {
    const responseMessage = null
    showProduct(req.query.produto).then(result => {
        responseMessage = result;
    })
    
    context.res = {
        body: responseMessage
    };
}