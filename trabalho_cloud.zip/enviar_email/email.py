import smtplib, ssl
import azure.functions as func


def main(msg: func.ServiceBusMessage):
    port = 587
    smtp_server = "smtp.gmail.com"
    sender_email = "rossipedro99@gmail.com"
    receiver_email = "rossipedro99@gmail.com"
    password = "senhatirada123"
    message = """\

    O produto """ +  msg.get_body().decode('utf-8') + """ foi cadastrado com sucesso"""

    context = ssl.create_default_context()
    with smtplib.SMTP(smtp_server, port) as server:
        server.ehlo()
        server.starttls(context=context)
        server.ehlo()
        server.login(sender_email, password)
        server.sendmail(sender_email, receiver_email, message)




