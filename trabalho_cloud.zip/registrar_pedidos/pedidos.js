const { Client } = require('pg');
const { ServiceBusClient } = require("@azure/service-bus");
const connectionString = "Endpoint=sb://p02fiap.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=E6QM8fiyQgArkujVlwB+GWQ2KJcf4q54eTlLrmvwFVQ=";
const queueName = "email"
const client = new Client({
    host: 'postgre01python.postgres.database.azure.com',
    user: 'pedro',
    database: 'postgres',
    password: 'SssSxyHY8e!(',
    port: 5432,
    ssl: true
});
const insertUser = async (userName, userRole) => {
    try {
        await client.connect();           
        await client.query(
            `INSERT INTO "vendas" ("nome_produto", "valor")  
             VALUES ($1, $2)`, [userName, userRole]); 
        return true;
    } catch (error) {
        console.error(error.stack);
        return false;
    } finally {
        await client.end();               
    }
};
module.exports = async function (context, req) {
    
    insertUser(req.query.produto, req.query.valor).then(result => {
    if (result) {
        console.log('User inserted');
    }
    });
    
    const messages = [
        { body: req.query.produto }
     ];

    const sbClient = new ServiceBusClient(connectionString);
    const sender = sbClient.createSender(queueName);

    try {
        let batch = await sender.createMessageBatch(); 
        for (let i = 0; i < messages.length; i++) {
        if (!batch.tryAddMessage(messages[i])) {
            await sender.sendMessages(batch);
            batch = await sender.createMessageBatch();
        }
    }
        await sender.sendMessages(batch);
        console.log(`Sent a batch of messages to the queue: ${queueName}`);
        await sender.close();
    } finally {
		await sbClient.close();
	}


    const responseMessage = "Produto " + req.query.produto + "De valor -> " + req.query.valor +"R$ Cadastrados com sucesso"

    context.res = {
        body: responseMessage
    };
}